import asyncio
import os
import threading
import uvicorn
from bot import bot, dp, init_db, start_scheduler, stop_scheduler
from app import app

PORT = int(os.environ.get("PORT", "8000"))


def run_api():
    uvicorn.run(app, host="0.0.0.0", port=PORT)


async def run_bot():
    init_db()
    start_scheduler()
    await dp.start_polling(bot)
    stop_scheduler()


async def main():
    api_thread = threading.Thread(target=run_api, daemon=True)
    api_thread.start()
    await run_bot()


if __name__ == "__main__":
    asyncio.run(main())
