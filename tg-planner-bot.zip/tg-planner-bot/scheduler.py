import asyncio
from datetime import datetime, timedelta
from apscheduler.schedulers.asyncio import AsyncIOScheduler
from apscheduler.triggers.date import DateTrigger
from apscheduler.triggers.cron import CronTrigger
import json

from db import get_active_reminders, deactivate_reminder, update_reminder_time
from config import BOT_TOKEN
from aiogram import Bot

bot = Bot(token=BOT_TOKEN)
scheduler = AsyncIOScheduler()


def _next_repeat(reminder: dict) -> datetime:
    """Вычисляет следующее время для повторяющегося напоминания."""
    now = datetime.now()
    repeat_type = reminder["repeat_type"]
    repeat_data = json.loads(reminder["repeat_data"] or "{}")
    current = datetime.fromisoformat(reminder["remind_at"])

    if repeat_type == "daily":
        return current + timedelta(days=1)
    elif repeat_type == "weekly":
        return current + timedelta(weeks=1)
    elif repeat_type == "custom":
        interval = repeat_data.get("interval_minutes", 1440)
        return current + timedelta(minutes=interval)
    return None


async def _send_reminder(reminder_id: int):
    from db import get_conn
    with get_conn() as conn:
        row = conn.execute("SELECT * FROM reminders WHERE id = ?", (reminder_id,)).fetchone()
        if not row:
            return
        reminder = dict(row)

    if not reminder["is_active"]:
        return

    user_id = reminder["user_id"]
    title = reminder["title"]
    text = f"⏰ Напоминание: <b>{title}</b>"

    try:
        await bot.send_message(user_id, text, parse_mode="HTML")
    except Exception as e:
        print(f"Ошибка отправки напоминания {reminder_id}: {e}")

    next_time = _next_repeat(reminder)
    if next_time:
        update_reminder_time(reminder_id, next_time.isoformat())
        scheduler.add_job(
            _send_reminder,
            trigger=DateTrigger(run_date=next_time),
            args=[reminder_id],
            id=f"reminder_{reminder_id}_{next_time.isoformat()}",
            replace_existing=True
        )
    else:
        deactivate_reminder(reminder_id)


def schedule_existing_reminders():
    """Загружает активные напоминания из БД при старте."""
    reminders = get_active_reminders()
    now = datetime.now()
    for r in reminders:
        remind_at = datetime.fromisoformat(r["remind_at"])
        if remind_at < now:
            remind_at = now + timedelta(seconds=5)
        scheduler.add_job(
            _send_reminder,
            trigger=DateTrigger(run_date=remind_at),
            args=[r["id"]],
            id=f"reminder_{r['id']}",
            replace_existing=True
        )


def add_job(reminder_id: int, remind_at: datetime):
    scheduler.add_job(
        _send_reminder,
        trigger=DateTrigger(run_date=remind_at),
        args=[reminder_id],
        id=f"reminder_{reminder_id}",
        replace_existing=True
    )


def start_scheduler():
    scheduler.start()
    schedule_existing_reminders()


def stop_scheduler():
    scheduler.shutdown()
