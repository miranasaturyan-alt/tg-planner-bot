import json
from datetime import datetime, timedelta
from fastapi import FastAPI, Request, HTTPException
from fastapi.staticfiles import StaticFiles
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel
from typing import Optional, List

from db import get_tasks, get_tasks_for_date, add_task, get_task, update_task_status, delete_task, add_reminder, get_reminders, delete_reminder
from scheduler import add_job

app = FastAPI()

# CORS для Telegram WebApp
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

app.mount("/static", StaticFiles(directory="miniapp"), name="static")


# --- Models ---

class TaskCreate(BaseModel):
    user_id: int
    title: str
    description: Optional[str] = ""
    duration_minutes: int = 60
    scheduled_date: Optional[str] = None
    scheduled_time: Optional[str] = None
    deadline: Optional[str] = None


class ReminderCreate(BaseModel):
    user_id: int
    title: str
    remind_at: str
    repeat_type: str = "once"


class TaskStatusUpdate(BaseModel):
    status: str


# --- API Endpoints ---

@app.get("/api/tasks")
def api_tasks(user_id: int):
    return {"tasks": get_tasks(user_id)}


@app.get("/api/tasks/date/{date_str}")
def api_tasks_by_date(date_str: str, user_id: int):
    return {"tasks": get_tasks_for_date(user_id, date_str)}


@app.post("/api/tasks")
def api_create_task(task: TaskCreate):
    task_id = add_task(
        user_id=task.user_id,
        title=task.title,
        description=task.description,
        duration_minutes=task.duration_minutes,
        scheduled_date=task.scheduled_date,
        scheduled_time=task.scheduled_time,
        deadline=task.deadline
    )
    return {"id": task_id, "status": "created"}


@app.patch("/api/tasks/{task_id}")
def api_update_task(task_id: int, update: TaskStatusUpdate):
    update_task_status(task_id, update.status)
    return {"status": "updated"}


@app.delete("/api/tasks/{task_id}")
def api_delete_task(task_id: int):
    delete_task(task_id)
    return {"status": "deleted"}


@app.get("/api/reminders")
def api_reminders(user_id: int):
    return {"reminders": get_reminders(user_id)}


@app.post("/api/reminders")
def api_create_reminder(r: ReminderCreate):
    remind_at = datetime.fromisoformat(r.remind_at)
    rid = add_reminder(
        user_id=r.user_id,
        title=r.title,
        remind_at=r.remind_at,
        repeat_type=r.repeat_type
    )
    add_job(rid, remind_at)
    return {"id": rid, "status": "created"}


@app.delete("/api/reminders/{reminder_id}")
def api_delete_reminder(reminder_id: int):
    delete_reminder(reminder_id)
    return {"status": "deleted"}


# --- Root redirect to miniapp ---

@app.get("/")
def root():
    return {"message": "Planner API is running. Open /static/index.html for the mini app."}
