import sqlite3
import json
from datetime import datetime, timedelta
from typing import Optional, List, Dict, Any
from config import DB_PATH


def get_conn():
    conn = sqlite3.connect(DB_PATH)
    conn.row_factory = sqlite3.Row
    return conn


def init_db():
    with get_conn() as conn:
        conn.executescript("""
            CREATE TABLE IF NOT EXISTS tasks (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                user_id INTEGER NOT NULL,
                title TEXT NOT NULL,
                description TEXT DEFAULT '',
                duration_minutes INTEGER DEFAULT 60,
                scheduled_date TEXT,
                scheduled_time TEXT,
                deadline TEXT,
                status TEXT DEFAULT 'active',
                created_at TEXT DEFAULT CURRENT_TIMESTAMP
            );

            CREATE TABLE IF NOT EXISTS reminders (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                task_id INTEGER,
                user_id INTEGER NOT NULL,
                title TEXT NOT NULL,
                remind_at TEXT NOT NULL,
                repeat_type TEXT DEFAULT 'once',
                repeat_data TEXT DEFAULT '{}',
                is_active INTEGER DEFAULT 1,
                created_at TEXT DEFAULT CURRENT_TIMESTAMP,
                FOREIGN KEY(task_id) REFERENCES tasks(id) ON DELETE CASCADE
            );
        """)


# --- Tasks ---

def add_task(user_id: int, title: str, description: str = "",
             duration_minutes: int = 60, scheduled_date: str = None,
             scheduled_time: str = None, deadline: str = None) -> int:
    with get_conn() as conn:
        cur = conn.execute(
            """INSERT INTO tasks (user_id, title, description, duration_minutes,
                scheduled_date, scheduled_time, deadline)
               VALUES (?, ?, ?, ?, ?, ?, ?)""",
            (user_id, title, description, duration_minutes,
             scheduled_date, scheduled_time, deadline)
        )
        return cur.lastrowid


def get_tasks(user_id: int, status: str = None) -> List[Dict[str, Any]]:
    with get_conn() as conn:
        sql = "SELECT * FROM tasks WHERE user_id = ?"
        params = [user_id]
        if status:
            sql += " AND status = ?"
            params.append(status)
        sql += " ORDER BY deadline IS NULL, deadline, created_at DESC"
        rows = conn.execute(sql, params).fetchall()
        return [dict(r) for r in rows]


def get_task(task_id: int) -> Optional[Dict[str, Any]]:
    with get_conn() as conn:
        row = conn.execute("SELECT * FROM tasks WHERE id = ?", (task_id,)).fetchone()
        return dict(row) if row else None


def update_task_status(task_id: int, status: str):
    with get_conn() as conn:
        conn.execute("UPDATE tasks SET status = ? WHERE id = ?", (status, task_id))


def delete_task(task_id: int):
    with get_conn() as conn:
        conn.execute("DELETE FROM tasks WHERE id = ?", (task_id,))


def get_tasks_for_date(user_id: int, date_str: str) -> List[Dict[str, Any]]:
    with get_conn() as conn:
        rows = conn.execute(
            "SELECT * FROM tasks WHERE user_id = ? AND scheduled_date = ? AND status = 'active' ORDER BY scheduled_time",
            (user_id, date_str)
        ).fetchall()
        return [dict(r) for r in rows]


# --- Reminders ---

def add_reminder(user_id: int, title: str, remind_at: str,
                 task_id: int = None, repeat_type: str = "once",
                 repeat_data: dict = None) -> int:
    repeat_json = json.dumps(repeat_data or {})
    with get_conn() as conn:
        cur = conn.execute(
            """INSERT INTO reminders (user_id, task_id, title, remind_at,
                repeat_type, repeat_data)
               VALUES (?, ?, ?, ?, ?, ?)""",
            (user_id, task_id, title, remind_at, repeat_type, repeat_json)
        )
        return cur.lastrowid


def get_active_reminders() -> List[Dict[str, Any]]:
    with get_conn() as conn:
        rows = conn.execute(
            "SELECT * FROM reminders WHERE is_active = 1"
        ).fetchall()
        return [dict(r) for r in rows]


def get_reminders(user_id: int) -> List[Dict[str, Any]]:
    with get_conn() as conn:
        rows = conn.execute(
            "SELECT * FROM reminders WHERE user_id = ? ORDER BY remind_at",
            (user_id,)
        ).fetchall()
        return [dict(r) for r in rows]


def deactivate_reminder(reminder_id: int):
    with get_conn() as conn:
        conn.execute("UPDATE reminders SET is_active = 0 WHERE id = ?", (reminder_id,))


def delete_reminder(reminder_id: int):
    with get_conn() as conn:
        conn.execute("DELETE FROM reminders WHERE id = ?", (reminder_id,))


def update_reminder_time(reminder_id: int, new_time: str):
    with get_conn() as conn:
        conn.execute("UPDATE reminders SET remind_at = ? WHERE id = ?",
                     (new_time, reminder_id))
