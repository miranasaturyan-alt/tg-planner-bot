const API_BASE = window.location.origin + '/api';
let tg = window.Telegram.WebApp;
let userId = null;

const COLORS = [
    '#2481cc', '#34c759', '#ff9500', '#ff3b30', '#af52de',
    '#5856d6', '#007aff', '#5ac8fa', '#ffcc00', '#ff2d55'
];

function getColor(index) {
    return COLORS[index % COLORS.length];
}

document.addEventListener('DOMContentLoaded', () => {
    tg.ready();
    tg.expand();
    tg.enableClosingConfirmation();

    // Получаем user_id
    if (tg.initDataUnsafe && tg.initDataUnsafe.user) {
        userId = tg.initDataUnsafe.user.id;
    } else {
        // Для теста в браузере
        userId = parseInt(new URLSearchParams(window.location.search).get('user_id')) || 1;
    }

    // Табы
    document.querySelectorAll('.tab').forEach(btn => {
        btn.addEventListener('click', () => {
            document.querySelectorAll('.tab').forEach(b => b.classList.remove('active'));
            document.querySelectorAll('.tab-content').forEach(c => c.classList.remove('active'));
            btn.classList.add('active');
            document.getElementById(btn.dataset.tab).classList.add('active');

            if (btn.dataset.tab === 'tasks') loadTasks();
            if (btn.dataset.tab === 'reminders') loadReminders();
        });
    });

    // Роадмап
    const today = new Date().toISOString().split('T')[0];
    document.getElementById('roadmap-date').value = today;
    document.getElementById('roadmap-date').addEventListener('change', renderRoadmap);
    document.getElementById('today-btn').addEventListener('click', () => {
        document.getElementById('roadmap-date').value = today;
        renderRoadmap();
    });
    renderTimeLabels();
    renderRoadmap();

    // Дела
    document.getElementById('add-task-btn').addEventListener('click', addTask);

    // Напоминания
    document.getElementById('add-remind-btn').addEventListener('click', addReminder);
});

// --- Loading ---
function showLoading() {
    document.getElementById('loading').classList.remove('hidden');
}
function hideLoading() {
    document.getElementById('loading').classList.add('hidden');
}

// --- API ---
async function apiGet(path) {
    const res = await fetch(`${API_BASE}${path}?user_id=${userId}`);
    if (!res.ok) throw new Error(await res.text());
    return res.json();
}
async function apiPost(path, body) {
    const res = await fetch(`${API_BASE}${path}`, {
        method: 'POST',
        headers: {'Content-Type': 'application/json'},
        body: JSON.stringify({...body, user_id: userId})
    });
    if (!res.ok) throw new Error(await res.text());
    return res.json();
}
async function apiPatch(path, body) {
    const res = await fetch(`${API_BASE}${path}`, {
        method: 'PATCH',
        headers: {'Content-Type': 'application/json'},
        body: JSON.stringify(body)
    });
    if (!res.ok) throw new Error(await res.text());
    return res.json();
}
async function apiDelete(path) {
    const res = await fetch(`${API_BASE}${path}`, {method: 'DELETE'});
    if (!res.ok) throw new Error(await res.text());
    return res.json();
}

// --- Roadmap ---
function renderTimeLabels() {
    const container = document.getElementById('time-labels');
    container.innerHTML = '';
    const pxPerHour = 30;
    for (let h = 0; h <= 24; h++) {
        const label = document.createElement('div');
        label.className = 'time-label';
        label.style.top = (h * pxPerHour) + 'px';
        label.textContent = `${h}:00`;
        container.appendChild(label);

        const slot = document.createElement('div');
        slot.className = 'roadmap-slot';
        slot.style.top = (h * pxPerHour) + 'px';
        container.appendChild(slot);
    }
}

function parseTime(timeStr) {
    if (!timeStr) return null;
    const [h, m] = timeStr.split(':').map(Number);
    return h * 60 + m;
}

function timeToPx(minutes, pxPerHour = 30) {
    return (minutes / 60) * pxPerHour;
}

async function renderRoadmap() {
    const dateStr = document.getElementById('roadmap-date').value;
    const canvas = document.getElementById('roadmap-canvas');
    canvas.innerHTML = '';

    try {
        const data = await apiGet(`/tasks/date/${dateStr}`);
        const tasks = data.tasks || [];

        // Сортируем по времени начала
        tasks.sort((a, b) => {
            const ta = parseTime(a.scheduled_time) || 0;
            const tb = parseTime(b.scheduled_time) || 0;
            return ta - tb;
        });

        // Раскладываем по колонкам (nasloivanie)
        const columns = []; // каждая колонка — массив задач

        tasks.forEach((task, idx) => {
            const startMin = parseTime(task.scheduled_time) || 0;
            const duration = task.duration_minutes || 60;
            const endMin = startMin + duration;

            let placed = false;
            for (let col of columns) {
                const last = col[col.length - 1];
                const lastEnd = (parseTime(last.scheduled_time) || 0) + (last.duration_minutes || 60);
                if (lastEnd <= startMin) {
                    col.push(task);
                    placed = true;
                    break;
                }
            }
            if (!placed) {
                columns.push([task]);
            }
        });

        const colWidth = columns.length > 0 ? (100 / columns.length) : 100;

        columns.forEach((col, colIndex) => {
            col.forEach(task => {
                const startMin = parseTime(task.scheduled_time) || 0;
                const duration = task.duration_minutes || 60;
                const top = timeToPx(startMin);
                const height = Math.max(timeToPx(duration), 24);

                const block = document.createElement('div');
                block.className = 'task-block';
                block.style.top = top + 'px';
                block.style.height = height + 'px';
                block.style.left = (colIndex * colWidth) + '%';
                block.style.width = `calc(${colWidth}% - 6px)`;
                block.style.marginLeft = '3px';
                block.style.backgroundColor = getColor(task.id);

                const startH = Math.floor(startMin / 60).toString().padStart(2, '0');
                const startM = (startMin % 60).toString().padStart(2, '0');
                const endMinTotal = startMin + duration;
                const endH = Math.floor(endMinTotal / 60).toString().padStart(2, '0');
                const endM = (endMinTotal % 60).toString().padStart(2, '0');

                block.innerHTML = `
                    <div class="task-time">${startH}:${startM} - ${endH}:${endM}</div>
                    <div class="task-title">${escapeHtml(task.title)}</div>
                `;
                canvas.appendChild(block);
            });
        });

    } catch (e) {
        canvas.innerHTML = '<div class="empty-state">Ошибка загрузки роадмапа</div>';
        console.error(e);
    }
}

// --- Tasks ---
async function loadTasks() {
    const list = document.getElementById('task-list');
    list.innerHTML = '';
    showLoading();
    try {
        const data = await apiGet('/tasks');
        const tasks = data.tasks || [];
        if (tasks.length === 0) {
            list.innerHTML = '<div class="empty-state">Нет дел. Добавь первое!</div>';
            return;
        }

        tasks.forEach(task => {
            const item = document.createElement('div');
            item.className = 'task-item' + (task.status === 'done' ? ' done' : '');

            const deadline = task.deadline ? `Дедлайн: ${formatDateTime(task.deadline)}` : '';
            const scheduled = task.scheduled_date
                ? `Расписание: ${task.scheduled_date}${task.scheduled_time ? ' ' + task.scheduled_time : ''}`
                : '';

            item.innerHTML = `
                <div class="task-info">
                    <div class="task-title-text">${escapeHtml(task.title)}</div>
                    <div class="task-meta">
                        ${task.duration_minutes} мин
                        ${scheduled ? ' | ' + scheduled : ''}
                        ${deadline ? ' | ' + deadline : ''}
                    </div>
                </div>
                <div class="task-actions">
                    ${task.status !== 'done' ? `<button class="btn-done" onclick="markDone(${task.id})">✓</button>` : ''}
                    <button class="btn-delete" onclick="removeTask(${task.id})">✕</button>
                </div>
            `;
            list.appendChild(item);
        });
    } catch (e) {
        list.innerHTML = '<div class="empty-state">Ошибка загрузки</div>';
    } finally {
        hideLoading();
    }
}

async function addTask() {
    const title = document.getElementById('task-title').value.trim();
    const duration = parseInt(document.getElementById('task-duration').value) || 60;
    const date = document.getElementById('task-date').value || null;
    const time = document.getElementById('task-time').value || null;
    const deadline = document.getElementById('task-deadline').value || null;

    if (!title) {
        tg.showAlert('Введи название дела');
        return;
    }

    showLoading();
    try {
        await apiPost('/tasks', {
            title,
            duration_minutes: duration,
            scheduled_date: date,
            scheduled_time: time,
            deadline
        });
        document.getElementById('task-title').value = '';
        document.getElementById('task-time').value = '';
        document.getElementById('task-deadline').value = '';
        await loadTasks();
        tg.showAlert('Дело добавлено!');
    } catch (e) {
        tg.showAlert('Ошибка: ' + e.message);
    } finally {
        hideLoading();
    }
}

async function markDone(id) {
    showLoading();
    try {
        await apiPatch(`/tasks/${id}`, {status: 'done'});
        await loadTasks();
    } catch (e) {
        tg.showAlert('Ошибка');
    } finally {
        hideLoading();
    }
}

async function removeTask(id) {
    tg.showConfirm('Удалить дело?', async (confirmed) => {
        if (!confirmed) return;
        showLoading();
        try {
            await apiDelete(`/tasks/${id}`);
            await loadTasks();
        } catch (e) {
            tg.showAlert('Ошибка');
        } finally {
            hideLoading();
        }
    });
}

// --- Reminders ---
async function loadReminders() {
    const list = document.getElementById('reminder-list');
    list.innerHTML = '';
    showLoading();
    try {
        const data = await apiGet('/reminders');
        const reminders = data.reminders || [];
        if (reminders.length === 0) {
            list.innerHTML = '<div class="empty-state">Нет напоминаний</div>';
            return;
        }

        reminders.forEach(r => {
            const item = document.createElement('div');
            item.className = 'reminder-item';
            const repeatText = {
                'once': 'Один раз',
                'daily': 'Каждый день',
                'weekly': 'Каждую неделю'
            }[r.repeat_type] || r.repeat_type;

            item.innerHTML = `
                <div class="task-info">
                    <div class="task-title-text">${escapeHtml(r.title)}</div>
                    <div class="task-meta">
                        ${formatDateTime(r.remind_at)} | ${repeatText}
                    </div>
                </div>
                <div class="reminder-actions">
                    <button class="btn-delete" onclick="removeReminder(${r.id})">✕</button>
                </div>
            `;
            list.appendChild(item);
        });
    } catch (e) {
        list.innerHTML = '<div class="empty-state">Ошибка загрузки</div>';
    } finally {
        hideLoading();
    }
}

async function addReminder() {
    const title = document.getElementById('remind-title').value.trim();
    const at = document.getElementById('remind-at').value;
    const repeat = document.getElementById('remind-repeat').value;

    if (!title || !at) {
        tg.showAlert('Заполни все поля');
        return;
    }

    showLoading();
    try {
        await apiPost('/reminders', {
            title,
            remind_at: new Date(at).toISOString(),
            repeat_type: repeat
        });
        document.getElementById('remind-title').value = '';
        document.getElementById('remind-at').value = '';
        await loadReminders();
        tg.showAlert('Напоминание добавлено!');
    } catch (e) {
        tg.showAlert('Ошибка: ' + e.message);
    } finally {
        hideLoading();
    }
}

async function removeReminder(id) {
    tg.showConfirm('Удалить напоминание?', async (confirmed) => {
        if (!confirmed) return;
        showLoading();
        try {
            await apiDelete(`/reminders/${id}`);
            await loadReminders();
        } catch (e) {
            tg.showAlert('Ошибка');
        } finally {
            hideLoading();
        }
    });
}

// --- Utils ---
function escapeHtml(text) {
    const div = document.createElement('div');
    div.textContent = text;
    return div.innerHTML;
}

function formatDateTime(iso) {
    if (!iso) return '';
    const d = new Date(iso);
    if (isNaN(d)) return iso;
    return d.toLocaleString('ru-RU', {
        day: '2-digit', month: '2-digit', year: 'numeric',
        hour: '2-digit', minute: '2-digit'
    });
}
