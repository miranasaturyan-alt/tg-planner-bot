@echo off
chcp 65001 >nul
echo Запуск бота...
python bot.py
echo.
echo Бот остановлен.
pause
