import asyncio
import logging
from datetime import datetime, timedelta

from aiogram import Bot, Dispatcher, F, types
from aiogram.filters import CommandStart, Command
from aiogram.fsm.context import FSMContext
from aiogram.fsm.state import State, StatesGroup
from aiogram.fsm.storage.memory import MemoryStorage
from aiogram.types import InlineKeyboardMarkup, InlineKeyboardButton, WebAppInfo

from config import BOT_TOKEN, WEBAPP_URL, OWNER_ID
from db import init_db, add_task, get_tasks, get_task, update_task_status, delete_task, add_reminder
from scheduler import start_scheduler, stop_scheduler, add_job

logging.basicConfig(level=logging.INFO)

bot = Bot(token=BOT_TOKEN)
dp = Dispatcher(storage=MemoryStorage())


# --- States ---

class AddTask(StatesGroup):
    title = State()
    duration = State()
    date = State()
    time = State()
    deadline = State()


class AddReminder(StatesGroup):
    title = State()
    datetime = State()
    repeat = State()


# --- Helpers ---

def owner_only(handler):
    async def wrapper(message: types.Message, *args, **kwargs):
        if message.from_user.id != OWNER_ID:
            await message.answer("Этот бот только для личного пользования.")
            return
        return await handler(message, *args, **kwargs)
    return wrapper


def app_button():
    return InlineKeyboardMarkup(inline_keyboard=[
        [InlineKeyboardButton(text="Открыть мини-апп", web_app=WebAppInfo(url=WEBAPP_URL))]
    ])


# --- Handlers ---

@dp.message(CommandStart())
@owner_only
async def cmd_start(message: types.Message):
    await message.answer(
        f"Привет! Я твой личный планировщик.\n\n"
        f"Команды:\n"
        f"/add — добавить дело\n"
        f"/list — список дел\n"
        f"/done ID — отметить выполненным\n"
        f"/delete ID — удалить дело\n"
        f"/remind — добавить напоминание\n"
        f"/app — открыть мини-апп",
        reply_markup=app_button()
    )


@dp.message(Command("app"))
@owner_only
async def cmd_app(message: types.Message):
    await message.answer("Открой мини-апп:", reply_markup=app_button())


# --- Add task ---

@dp.message(Command("add"))
@owner_only
async def cmd_add(message: types.Message, state: FSMContext):
    await message.answer("Введи название дела:")
    await state.set_state(AddTask.title)


@dp.message(AddTask.title)
async def task_title(message: types.Message, state: FSMContext):
    await state.update_data(title=message.text)
    await message.answer("Длительность в минутах (например, 60):")
    await state.set_state(AddTask.duration)


@dp.message(AddTask.duration)
async def task_duration(message: types.Message, state: FSMContext):
    try:
        minutes = int(message.text)
    except ValueError:
        await message.answer("Введи число (минуты):")
        return
    await state.update_data(duration=minutes)
    await message.answer("Дата в формате ГГГГ-ММ-ДД (или '-' пропустить):")
    await state.set_state(AddTask.date)


@dp.message(AddTask.date)
async def task_date(message: types.Message, state: FSMContext):
    date_str = message.text.strip()
    if date_str == "-":
        date_str = None
    await state.update_data(date=date_str)
    await message.answer("Время начала в формате ЧЧ:ММ (или '-' пропустить):")
    await state.set_state(AddTask.time)


@dp.message(AddTask.time)
async def task_time(message: types.Message, state: FSMContext):
    time_str = message.text.strip()
    if time_str == "-":
        time_str = None
    await state.update_data(time=time_str)
    await message.answer("Дедлайн в формате ГГГГ-ММ-ДД ЧЧ:ММ (или '-' пропустить):")
    await state.set_state(AddTask.deadline)


@dp.message(AddTask.deadline)
async def task_deadline(message: types.Message, state: FSMContext):
    deadline_str = message.text.strip()
    if deadline_str == "-":
        deadline_str = None
    data = await state.get_data()
    await state.clear()

    task_id = add_task(
        user_id=message.from_user.id,
        title=data["title"],
        duration_minutes=data["duration"],
        scheduled_date=data.get("date"),
        scheduled_time=data.get("time"),
        deadline=deadline_str
    )
    await message.answer(f"Дело добавлено! ID: {task_id}\n\n/list — посмотреть все дела")


# --- List tasks ---

@dp.message(Command("list"))
@owner_only
async def cmd_list(message: types.Message):
    tasks = get_tasks(message.from_user.id, status="active")
    if not tasks:
        await message.answer("Нет активных дел.")
        return

    lines = []
    for t in tasks:
        deadline = t["deadline"] or "нет дедлайна"
        time_info = ""
        if t["scheduled_date"]:
            time_info = f" | {t['scheduled_date']}"
            if t["scheduled_time"]:
                time_info += f" {t['scheduled_time']}"
        lines.append(f"• <b>#{t['id']}</b> {t['title']}{time_info} | дедлайн: {deadline}")

    await message.answer("Активные дела:\n\n" + "\n".join(lines), parse_mode="HTML")


# --- Done / Delete ---

@dp.message(Command("done"))
@owner_only
async def cmd_done(message: types.Message):
    parts = message.text.split(maxsplit=1)
    if len(parts) < 2:
        await message.answer("Используй: /done ID")
        return
    try:
        task_id = int(parts[1])
    except ValueError:
        await message.answer("ID должен быть числом.")
        return

    t = get_task(task_id)
    if not t or t["user_id"] != message.from_user.id:
        await message.answer("Дело не найдено.")
        return

    update_task_status(task_id, "done")
    await message.answer(f"Дело #{task_id} отмечено выполненным!")


@dp.message(Command("delete"))
@owner_only
async def cmd_delete(message: types.Message):
    parts = message.text.split(maxsplit=1)
    if len(parts) < 2:
        await message.answer("Используй: /delete ID")
        return
    try:
        task_id = int(parts[1])
    except ValueError:
        await message.answer("ID должен быть числом.")
        return

    t = get_task(task_id)
    if not t or t["user_id"] != message.from_user.id:
        await message.answer("Дело не найдено.")
        return

    delete_task(task_id)
    await message.answer(f"Дело #{task_id} удалено.")


# --- Reminders ---

@dp.message(Command("remind"))
@owner_only
async def cmd_remind(message: types.Message, state: FSMContext):
    await message.answer("Введи текст напоминания:")
    await state.set_state(AddReminder.title)


@dp.message(AddReminder.title)
async def remind_title(message: types.Message, state: FSMContext):
    await state.update_data(title=message.text)
    await message.answer("Когда напомнить? Формат: ГГГГ-ММ-ДД ЧЧ:ММ")
    await state.set_state(AddReminder.datetime)


@dp.message(AddReminder.datetime)
async def remind_datetime(message: types.Message, state: FSMContext):
    dt_str = message.text.strip()
    try:
        remind_at = datetime.strptime(dt_str, "%Y-%m-%d %H:%M")
    except ValueError:
        await message.answer("Неверный формат. Используй: ГГГГ-ММ-ДД ЧЧ:ММ")
        return

    await state.update_data(datetime=remind_at)
    kb = InlineKeyboardMarkup(inline_keyboard=[
        [InlineKeyboardButton(text="Один раз", callback_data="repeat:once")],
        [InlineKeyboardButton(text="Каждый день", callback_data="repeat:daily")],
        [InlineKeyboardButton(text="Каждую неделю", callback_data="repeat:weekly")],
    ])
    await message.answer("Повторять?", reply_markup=kb)


@dp.callback_query(F.data.startswith("repeat:"))
async def remind_repeat(callback: types.CallbackQuery, state: FSMContext):
    repeat_type = callback.data.split(":")[1]
    data = await state.get_data()
    await state.clear()

    remind_at = data["datetime"]
    repeat_data = {}
    if repeat_type == "custom":
        repeat_data = {"interval_minutes": 1440}

    rid = add_reminder(
        user_id=callback.from_user.id,
        title=data["title"],
        remind_at=remind_at.isoformat(),
        repeat_type=repeat_type,
        repeat_data=repeat_data
    )
    add_job(rid, remind_at)
    await callback.message.edit_text(f"Напоминание добавлено! ID: {rid}")


# --- Main ---

async def main():
    init_db()
    start_scheduler()
    await dp.start_polling(bot)
    stop_scheduler()


if __name__ == "__main__":
    asyncio.run(main())
